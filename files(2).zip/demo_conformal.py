"""
Demo: particle-ensemble rollouts + split conformal calibration for
calibrated per-timestep latent error bars, on the Neural ODE dynamics.

    python -m lytimet.demo_conformal
"""
import os

import jax

from .model import LyTimeT, LyTimeTConfig
from .data import make_pendulum_batch
from .train import Phase1Config, train_phase1
from .conformal import calibrate_conformal, predict_with_interval, evaluate_coverage
from .plot import plot_conformal_band, plot_coverage_diagnostic


def main():
    cfg = LyTimeTConfig(
        image_size=32, patch_size=4, in_channels=1, dim=64, depth=2,
        num_heads=4, dz=8, clip_len=10, transition_hidden=64, transition_depth=2,
        dynamics_type="neural_ode", ode_solver_steps=3, ode_dt=1.0,
    )
    key = jax.random.PRNGKey(0)
    k_model, k_train, k_calib, k_test, k_pred = jax.random.split(key, 5)
    model = LyTimeT(cfg, key=k_model)

    def data_fn(k, b):
        clips, _ = make_pendulum_batch(k, b, cfg.clip_len, cfg.image_size)
        return clips

    print("=== Phase 1: representation + forecasting (Neural ODE dynamics) ===")
    p1_cfg = Phase1Config(lr=3e-4, k_steps=4, num_steps=60, batch_size=6)
    model, hist1 = train_phase1(model, data_fn, p1_cfg, k_train, log_every=15)

    k_steps = 5
    num_particles = 30
    noise_std = 0.05
    alpha = 0.1  # target 90% coverage

    print("\n=== Calibrating conformal intervals on held-out clips ===")
    calib_clips = data_fn(k_calib, 60)
    q_hat = calibrate_conformal(
        model, calib_clips, k_steps, num_particles, noise_std, alpha, k_calib
    )
    print("q_hat (per step, mean over latent dims):", q_hat.mean(axis=-1))

    print("\n=== Checking empirical coverage on a fresh test set ===")
    test_clips = data_fn(k_test, 100)
    coverage = evaluate_coverage(
        model, test_clips, k_steps, num_particles, noise_std, q_hat, k_test
    )
    print("Empirical coverage per step (target = "
          f"{1 - alpha:.0%}):", coverage.mean(axis=-1))

    print("\n=== Plotting example rollout with calibrated intervals ===")
    os.makedirs("plots_conformal", exist_ok=True)
    example_clip = test_clips[0]
    z_true, _ = model.encode(example_clip)
    mean, lower, upper = predict_with_interval(
        model, z_true[0], k_steps, num_particles, noise_std, q_hat, k_pred
    )
    plot_conformal_band(
        z_true[1 : 1 + k_steps], mean, lower, upper,
        save_path="plots_conformal/conformal_band.png",
    )
    plot_coverage_diagnostic(
        coverage, target_coverage=1 - alpha,
        save_path="plots_conformal/coverage_diagnostic.png",
    )
    print("Saved plots to ./plots_conformal/")


if __name__ == "__main__":
    main()
