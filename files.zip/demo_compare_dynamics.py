"""
Compares the paper-faithful discrete residual-MLP transition against the
optional Neural ODE transition (see ode_transition.py), training each
through both phases and plotting rollout error vs. horizon for all three
checkpoints (residual-MLP after Phase 1, residual-MLP after Phase 2, and
neural-ODE after Phase 2) on the same held-out clips.

    python -m lytimet.demo_compare_dynamics
"""
import jax

from .model import LyTimeT, LyTimeTConfig
from .data import make_pendulum_batch
from .train import Phase1Config, Phase2Config, train_phase1, train_phase2
from .plot import plot_rollout_error_vs_horizon, plot_training_curves


def train_one(cfg, key, use_continuous_lyapunov):
    k_model, k_phase1, k_phase2 = jax.random.split(key, 3)
    model = LyTimeT(cfg, key=k_model)

    def data_fn_clips(k, b):
        clips, _ = make_pendulum_batch(k, b, cfg.clip_len, cfg.image_size)
        return clips

    def data_fn_clips_and_states(k, b):
        return make_pendulum_batch(k, b, cfg.clip_len, cfg.image_size)

    p1_cfg = Phase1Config(lr=3e-4, k_steps=3, num_steps=30, batch_size=4)
    model, hist1 = train_phase1(model, data_fn_clips, p1_cfg, k_phase1, log_every=10)
    model_after_p1 = model

    p2_cfg = Phase2Config(
        lr=1e-4, k_steps=3, lambda_lyap=0.1, num_steps=20, batch_size=4,
        n_select=2, use_continuous_lyapunov=use_continuous_lyapunov,
    )
    model, w_lyap, select_idx, hist2 = train_phase2(
        model, data_fn_clips_and_states, p2_cfg, k_phase2, log_every=10
    )
    return model_after_p1, model, hist1, hist2


def main():
    base_cfg = dict(
        image_size=32, patch_size=4, in_channels=1, dim=64, depth=2,
        num_heads=4, dz=8, clip_len=8, transition_hidden=64, transition_depth=2,
    )
    key = jax.random.PRNGKey(0)
    k_mlp, k_ode, k_eval = jax.random.split(key, 3)

    print("=== Training: residual-MLP dynamics (paper default) ===")
    mlp_cfg = LyTimeTConfig(**base_cfg, dynamics_type="residual_mlp")
    mlp_p1, mlp_p2, mlp_hist1, mlp_hist2 = train_one(
        mlp_cfg, k_mlp, use_continuous_lyapunov=False
    )

    print("\n=== Training: Neural ODE dynamics (alternative) ===")
    ode_cfg = LyTimeTConfig(
        **base_cfg, dynamics_type="neural_ode", ode_solver_steps=3, ode_dt=1.0
    )
    ode_p1, ode_p2, ode_hist1, ode_hist2 = train_one(
        ode_cfg, k_ode, use_continuous_lyapunov=True
    )

    print("\n=== Plotting comparison ===")
    eval_clips, _ = make_pendulum_batch(k_eval, 8, base_cfg["clip_len"], base_cfg["image_size"])

    import os
    os.makedirs("plots_compare", exist_ok=True)

    plot_rollout_error_vs_horizon(
        {
            "Residual-MLP, Phase 1 only": mlp_p1,
            "Residual-MLP + discrete Lyapunov": mlp_p2,
            "Neural ODE + continuous Lyapunov": ode_p2,
        },
        eval_clips,
        max_k=3,
        save_path="plots_compare/dynamics_comparison.png",
    )
    plot_training_curves(mlp_hist1, mlp_hist2, save_path="plots_compare/mlp_loss.png")
    plot_training_curves(ode_hist1, ode_hist2, save_path="plots_compare/ode_loss.png")
    print("Saved plots to ./plots_compare/")


if __name__ == "__main__":
    main()
